Paquete de sitio estático "Cosinsa Ingeniería y Construcción"
Carpeta raíz: /mnt/data/cosinsa_website

Estructura:
- index.html
- Nosotros.html
- Servicios.html
- Experiencia.html
- Contacto.html
- css/style.css
- img/logo.png

Instrucciones rápidas:
1) Descomprime el archivo y revisa los archivos en un editor de texto (p.ej. VSCode o Notepad++).
2) Reemplaza img/logo.png por tu logo real manteniendo el mismo nombre, o cambia la referencia en los HTML.
3) Sube la carpeta al repositorio de GitHub siguiendo las instrucciones que te daré después.

